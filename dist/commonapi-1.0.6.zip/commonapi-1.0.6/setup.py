from distutils.core import setup

# pip install commonapi-1.0.1.zip
# python setup.py sdist
# \dev\python27\python setup.py build

setup(
    name='commonapi',
    version='1.0.6',
    packages=['', 'commonapi'],
    url='',
    license='',
    author='yoramk',
    author_email='',
    description='',
    zip_safe=False
)
