from distutils.core import setup

# pip install halolib-1.0.1.zip
# python setup.py sdist
# \dev\python27\python setup.py build

setup(
    name='halolib',
    version='0.11.13',
    packages=['', 'halolib'],
    url='',
    license='',
    author='yoramk2',
    author_email='',
    description='this is the Halo framework library',
    zip_safe=False
)
