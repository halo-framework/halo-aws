from __future__ import print_function

flx = False
try:
    from django.conf import settings
    #from flask import current_app as app
    #flx = True
except:
    from flask import current_app as app
    flx = True


class settingsx(object):
    def __getattribute__(self, name):
        global flx
        if not flx:
            from django.conf import settings
            return settings.__getattr__(name)
        settings = app.config
        attr = settings.get(name)
        return attr
